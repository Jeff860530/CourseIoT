

if __name__ == '__main__':

    Str1 = '14:59~15:20'
    StrList = Str1.split('~')
    print(StrList)
    print(StrList[0])
    print(StrList[1])
